package main.metamodel;

import java.util.List;

public class Machine {

	public List<State> getStates() {
		// TODO Auto-generated method stub
		return null;
	}

	public State getInitialState() {
		// TODO Auto-generated method stub
		return null;
	}

	public State getState(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public int numberOfIntegers() {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean hasInteger(String string) {
		// TODO Auto-generated method stub
		return false;
	}
}

