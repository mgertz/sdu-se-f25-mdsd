package main.metamodel;

import java.util.List;

public class State {

	public Object getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Transition> getTransitions() {
		// TODO Auto-generated method stub
		return null;
	}

	public Transition getTransitionByEvent(String string) {
		// TODO Auto-generated method stub
		return null;
	}
}
